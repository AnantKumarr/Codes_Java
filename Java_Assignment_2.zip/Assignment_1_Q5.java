import java.util.Scanner;

 class SentenceAnalyzer {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        
        System.out.print("Enter a sentence: ");
        String sentence = sc.nextLine();
        
        int wordCount = countWords(sentence);
        System.out.println("Number of words int the sentence are : " + wordCount);
        
        String[] words = sentence.split(" ");
        System.out.println("Palindrome word int the sentence are :");
        for (String word : words) {
            if (isPalindrome(word)) {
                System.out.println(word);
            }
        }
        
        sc.close();
    }
    
    
    public static int countWords(String sentence) {
        String[] words = sentence.split(" ");
        return words.length;
    }
    
    
    public static boolean isPalindrome(String word) {
        int left = 0;
        int right = word.length() - 1;
        
        while (left < right) {
            if (word.charAt(left) != word.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        
        return true;
    }
}
